import React, { Component } from "react";
import BookingDetails from "./BookingDetails";
import "./DealsMaster.css";

import dateFormat from "dateformat";

export default class DealsMaster extends Component {
  render() {
    console.log(dateFormat(new Date(), "dd mmm yyyy"));
    return (
      <div>
        <div className="nursemasterheader">
          <div className="titleuser">DEALS</div>
        </div>
        <BookingDetails />
      </div>
    );
  }
}
